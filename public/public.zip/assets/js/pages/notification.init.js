/*
Product Name: Doctorly - Patient Management System
Author: Themesbrand
Version: 1.0.0
Website: https://themesbrand.com/
Contact: support@themesbrand.com
File: Notification
*/

$(document).ready(function(){

    setTimeout(function(){

        $(".auto").slideUp(1000);

    }, 6000);

});
